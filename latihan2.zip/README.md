# latihan2

Project gabungan dari seluruh tugas laravel 

Nama : Muhammad Amrin Mukhodas
NIM : 3042019009
