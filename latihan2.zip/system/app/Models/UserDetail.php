<?php 
namespace App\Models;

class UserDetail extends Model
{
	protected $table = 'user_detail';
}